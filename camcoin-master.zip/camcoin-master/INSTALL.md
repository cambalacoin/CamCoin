Building Camcoin
================

See doc/build-*.md for instructions on building the various
elements of the Camcoin Core reference implementation of Camcoin.

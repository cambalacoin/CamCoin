// Copyright (c) 2011-2014 The Camcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef CAMCOIN_QT_CAMCOINADDRESSVALIDATOR_H
#define CAMCOIN_QT_CAMCOINADDRESSVALIDATOR_H

#include <QValidator>

/** Base58 entry widget validator, checks for valid characters and
 * removes some whitespace.
 */
class CamcoinAddressEntryValidator : public QValidator
{
    Q_OBJECT

public:
    explicit CamcoinAddressEntryValidator(QObject *parent);

    State validate(QString &input, int &pos) const;
};

/** Camcoin address widget validator, checks for a valid camcoin address.
 */
class CamcoinAddressCheckValidator : public QValidator
{
    Q_OBJECT

public:
    explicit CamcoinAddressCheckValidator(QObject *parent);

    State validate(QString &input, int &pos) const;
};

#endif // CAMCOIN_QT_CAMCOINADDRESSVALIDATOR_H

Gitian building
================

This file was moved to [the Camcoin Core documentation repository](https://github.com/camcoin-core/docs/blob/master/gitian-building.md) at [https://github.com/camcoin-core/docs](https://github.com/camcoin-core/docs).

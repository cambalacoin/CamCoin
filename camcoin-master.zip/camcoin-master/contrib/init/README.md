Sample configuration files for:
```
SystemD: camcoind.service
Upstart: camcoind.conf
OpenRC:  camcoind.openrc
         camcoind.openrcconf
CentOS:  camcoind.init
OS X:    org.camcoin.camcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
